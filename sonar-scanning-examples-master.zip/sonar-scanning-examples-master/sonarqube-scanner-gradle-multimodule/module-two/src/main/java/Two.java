public class Two {
  public String foo() {
    return "foo";
  }
}
